import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Readcsv {
    public static void main(String[] args) {
        try {
            Scanner scr = new Scanner(new File("src/data.csv"));
            scr.useDelimiter(",");
            while (scr.hasNext()){
                System.out.println(scr.next());
            }
        }
        catch (IOException e){
            e.printStackTrace();
        }
    }
}
