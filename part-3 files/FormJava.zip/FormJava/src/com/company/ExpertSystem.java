/**
 * This code is used to generate output labels for the input attributes of
 * the dataset. The output values i.e. labels are written in a output.csv file.
 * These values are then manually inserted in the csv file of input attributes.
 * The program starts generating data after the 'check security' button is
 * clicked in the desktop app generated first.
 */

package com.company;

import javafx.scene.control.RadioButton;
import jess.*;

import javax.swing.*;
import javax.xml.xpath.XPathEvaluationResult;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Iterator;
import java.util.Scanner;

public class ExpertSystem {
    private JRadioButton radioButton1;
    private JRadioButton radioButton2;
    private JButton button1;
    private JPanel jpanel;
    private JLabel installationFromUnknownSourcesLabel;
    private JRadioButton radioButton3;
    private JRadioButton radioButton4;
    private JRadioButton radioButton6;
    private JRadioButton radioButton5;
    private JRadioButton radioButton8;
    private JRadioButton radioButton7;
    private JRadioButton radioButton10;
    private JRadioButton radioButton9;
    private JRadioButton radioButton12;
    private JRadioButton radioButton11;
    private JRadioButton radioButton14;
    private JRadioButton radioButton13;
    private JComboBox apiLevel;
    private JRadioButton radioButton16;
    private JRadioButton radioButton15;
    private JRadioButton radioButton18;
    private JRadioButton radioButton17;
    private JTextField harmApps;
    private JLabel outputLable;
    private JLabel securityOutput;
    String unkSrcs = "";
    String devEncrypt = "";
    String scrnLock = "";
    String developerOpts = "";
    String simLock = "";
    String BTdiscoverable = "";
    String usbDebugging = "";
    String playProtect = "";
    String devTampTest = "";

    public ExpertSystem() {
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    System.out.println("Entered inside");
                    /*
                    if (radioButton1.isSelected()) {
                        unkSrcs = radioButton1.getText();
                    }
                    else if (radioButton2.isSelected()) {
                        unkSrcs = radioButton2.getText();
                    }

                    if (radioButton3.isSelected()) {
                        devEncrypt = radioButton3.getText();
                    }
                    else if (radioButton4.isSelected()) {
                        devEncrypt = radioButton4.getText();
                    }

                    if (radioButton5.isSelected()) {
                        scrnLock = radioButton5.getText();
                    }
                    else if (radioButton6.isSelected()) {
                        scrnLock = radioButton6.getText();
                    }

                    if (radioButton7.isSelected()) {
                        developerOpts = radioButton7.getText();
                    }
                    else if (radioButton8.isSelected()) {
                        developerOpts = radioButton8.getText();
                    }

                    if (radioButton9.isSelected()) {
                        simLock = radioButton9.getText();
                    }
                    else if (radioButton10.isSelected()) {
                        simLock = radioButton10.getText();
                    }

                    if (radioButton11.isSelected()) {
                        BTdiscoverable = radioButton11.getText();
                    }
                    else if (radioButton12.isSelected()) {
                        BTdiscoverable = radioButton12.getText();
                    }

                    if (radioButton13.isSelected()) {
                        usbDebugging = radioButton13.getText();
                    }
                    else if (radioButton14.isSelected()) {
                        usbDebugging = radioButton14.getText();
                    }

                    if (radioButton15.isSelected()) {
                        playProtect = radioButton15.getText();
                    }
                    else if (radioButton16.isSelected()) {
                        playProtect = radioButton16.getText();
                    }

                    if (radioButton17.isSelected()) {
                        devTampTest = radioButton17.getText();
                    }
                    else if (radioButton18.isSelected()) {
                        devTampTest = radioButton18.getText();
                    }

                    String numHarmfulApps = harmApps.getText();
                    String APILevel = apiLevel.getSelectedItem().toString();
                    if (APILevel.equals("<16"))
                        APILevel = "0";
                    */

                    String numHarmfulApps = "", APILevel = "";

                    Scanner scr = new Scanner(new File("src/data.csv"));
                    scr.useDelimiter(",");
                    int value, point = 0;
                    String result = "";
                    FileWriter fw = new FileWriter(new File("output.csv"));

                    while (scr.hasNext()) {
                        System.out.println("line number = " + (++point));

                        unkSrcs = ((value = scr.nextInt()) == 1) ? "Enabled"
                                : "Disabled";
//                        System.out.println("unknown source = " + unkSrcs);
                        devEncrypt = ((value = scr.nextInt()) == 1) ?
                                "Enabled" : "Disabled";
//                        System.out.println("devEncrypt = " + devEncrypt);
                        scrnLock = ((value = scr.nextInt()) == 1) ?
                                "Enabled" : "Disabled";
//                        System.out.println("scrnLock = " + scrnLock);
                        developerOpts = ((value = scr.nextInt()) == 1) ?
                                "Enabled" : "Disabled";
//                        System.out.println("devoptions = " + developerOpts);
                        simLock = ((value = scr.nextInt()) == 1) ?
                                "Enabled" : "Disabled";
//                        System.out.println("simlock = " + simLock);
                        BTdiscoverable = ((value = scr.nextInt()) == 1) ?
                                "Enabled" : "Disabled";
//                        System.out.println("BTdiscov = " + BTdiscoverable);
                        usbDebugging = ((value = scr.nextInt()) == 1) ?
                                "Enabled" : "Disabled";
//                        System.out.println("usb = " + usbDebugging);
                        playProtect = ((value = scr.nextInt()) == 1) ?
                                "Enabled" : "Disabled";
//                        System.out.println("playprotect = " + playProtect);
                        devTampTest = ((value = scr.nextInt()) == 1) ?
                                "Passed" : "Failed";
//                        System.out.println("devtamp = " + devTampTest);
                        numHarmfulApps = scr.next();
//                        System.out.println("harmful apps = " + numHarmfulApps);
                        APILevel = scr.nextLine();
                        APILevel = APILevel.substring(1);
//                        System.out.println("APIlevel = " + APILevel);
//                        System.out.println("Values: ");
//                        System.out.println(unkSrcs);
//                        System.out.println(devEncrypt);

                        Rete engine = new Rete();
                        Writer writer = new StringWriter();
                        engine.addOutputRouter("t", writer);
//                    engine.batch("/Users/thesarang/FIS/Project21/src/com" +
//                                "/company/ES.clp");
                        engine.batch("/com/company/ES.clp");
                        engine.eval("(assert (Metric\n" +
                                "(name \"devEncrypt\")\n" +
                                "(value \"" + devEncrypt + "\")\n" +
                                "(weight 7)))");

                        engine.eval("(assert (Metric\n" +
                                "(name \"developerOpts\")\n" +
                                "(value \"" + developerOpts + "\")\n" +
                                "(weight 3)))");

                        engine.eval("(assert (Metric\n" +
                                "(name “apiLevel”)\n" +
                                "(value " + APILevel + ")\n" +
                                "(weight 7)))");
                        engine.eval("(assert (Metric\n" +
                                "(name “usbDebugging”)\n" +
                                "(value “" + usbDebugging + "”)\n" +
                                "(weight 5)))");
                        engine.eval("(assert (Metric\n" +
                                "(name “BTdiscoverable”)\n" +
                                "(value “" + BTdiscoverable + "”)\n" +
                                "(weight 2)))");
                        engine.eval("(assert (Metric\n" +
                                "(name “scrnLock”)\n" +
                                "(value “" + scrnLock + "”)\n" +
                                "(weight 9)))");
                        engine.eval("(assert (Metric\n" +
                                "(name “simLock”)\n" +
                                "(value “" + simLock + "”)\n" +
                                "(weight 1)))");
                        engine.eval("(assert (Metric\n" +
                                "(name “unkSrcs”)\n" +
                                "(value “" + unkSrcs + "”)\n" +
                                "(weight 4)))");
                        engine.eval("(assert (Metric\n" +
                                "(name “harmApps”)\n" +
                                "(value " + numHarmfulApps + ")\n" +
                                "(weight 4)))");

                        engine.eval("(assert (Metric\n" +
                                "(name “playProtect”)\n" +
                                "(value “" + playProtect + "”)\n" +
                                "(weight 5)))");
                        engine.eval("(assert (Metric\n" +
                                "(name “devTampTest”)\n" +
                                "(value “" + devTampTest + "”)\n" +
                                "(weight 10)))");

                        engine.run();
                        //System.out.println(writer.toString());
                        result = writer.toString();
                        System.out.println(result);
                        fw.write(result);
                    }
                    fw.close();
                    scr.close();
                    JOptionPane.showMessageDialog(null, result);
                }
                catch(Exception ee){
                    ee.getMessage();
                }

            }


        });
    }

    public static void main(String[] args) {
        JFrame jframe = new JFrame();
        jframe.setContentPane(new ExpertSystem().jpanel);
        jframe.setDefaultCloseOperation(jframe.EXIT_ON_CLOSE);
        jframe.pack();
        jframe.setVisible(true);

    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}


/*
package com.company;

import javafx.scene.control.RadioButton;
import jess.*;

import javax.swing.*;
import javax.xml.xpath.XPathEvaluationResult;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.util.Iterator;
import java.util.Scanner;

public class ExpertSystem {
    private JRadioButton radioButton1;
    private JRadioButton radioButton2;
    private JButton button1;
    private JPanel jpanel;
    private JLabel installationFromUnknownSourcesLabel;
    private JRadioButton radioButton3;
    private JRadioButton radioButton4;
    private JRadioButton radioButton6;
    private JRadioButton radioButton5;
    private JRadioButton radioButton8;
    private JRadioButton radioButton7;
    private JRadioButton radioButton10;
    private JRadioButton radioButton9;
    private JRadioButton radioButton12;
    private JRadioButton radioButton11;
    private JRadioButton radioButton14;
    private JRadioButton radioButton13;
    private JComboBox apiLevel;
    private JRadioButton radioButton16;
    private JRadioButton radioButton15;
    private JRadioButton radioButton18;
    private JRadioButton radioButton17;
    private JTextField harmApps;
    private JLabel outputLable;
    private JLabel securityOutput;
    String unkSrcs = "";
    String devEncrypt = "";
    String scrnLock = "";
    String developerOpts = "";
    String simLock = "";
    String BTdiscoverable = "";
    String usbDebugging = "";
    String playProtect = "";
    String devTampTest = "";

    public ExpertSystem() {
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                try {
                    if (radioButton1.isSelected()) {
                        unkSrcs = radioButton1.getText();
                    }
                    else if (radioButton2.isSelected()) {
                        unkSrcs = radioButton2.getText();
                    }

                    if (radioButton3.isSelected()) {
                        devEncrypt = radioButton3.getText();
                    }
                    else if (radioButton4.isSelected()) {
                        devEncrypt = radioButton4.getText();
                    }

                    if (radioButton5.isSelected()) {
                        scrnLock = radioButton5.getText();
                    }
                    else if (radioButton6.isSelected()) {
                        scrnLock = radioButton6.getText();
                    }

                    if (radioButton7.isSelected()) {
                        developerOpts = radioButton7.getText();
                    }
                    else if (radioButton8.isSelected()) {
                        developerOpts = radioButton8.getText();
                    }

                    if (radioButton9.isSelected()) {
                        simLock = radioButton9.getText();
                    }
                    else if (radioButton10.isSelected()) {
                        simLock = radioButton10.getText();
                    }

                    if (radioButton11.isSelected()) {
                        BTdiscoverable = radioButton11.getText();
                    }
                    else if (radioButton12.isSelected()) {
                        BTdiscoverable = radioButton12.getText();
                    }

                    if (radioButton13.isSelected()) {
                        usbDebugging = radioButton13.getText();
                    }
                    else if (radioButton14.isSelected()) {
                        usbDebugging = radioButton14.getText();
                    }

                    if (radioButton15.isSelected()) {
                        playProtect = radioButton15.getText();
                    }
                    else if (radioButton16.isSelected()) {
                        playProtect = radioButton16.getText();
                    }

                    if (radioButton17.isSelected()) {
                        devTampTest = radioButton17.getText();
                    }
                    else if (radioButton18.isSelected()) {
                        devTampTest = radioButton18.getText();
                    }



                    String numHarmfulApps = harmApps.getText();
                    String APILevel = apiLevel.getSelectedItem().toString();
                    if (APILevel.equals("<16"))
                        APILevel = "0";

                    Rete engine = new Rete();
                    Writer writer = new StringWriter();
                    engine.addOutputRouter("t", writer);
//                    engine.batch("/Users/thesarang/FIS/Project21/src/com" +
//                                "/company/ES.clp");
                    engine.batch("/com/company/ES.clp");
                    engine.eval("(assert (Metric\n" +
                            "(name \"devEncrypt\")\n" +
                            "(value \"" +devEncrypt+"\")\n" +
                            "(weight 7)))");

                    engine.eval("(assert (Metric\n" +
                            "(name \"developerOpts\")\n" +
                            "(value \"" + developerOpts +"\")\n" +
                            "(weight 3)))");

                    engine.eval("(assert (Metric\n" +
                            "(name “apiLevel”)\n" +
                            "(value "+ APILevel+ ")\n" +
                            "(weight 7)))");
                    engine.eval("(assert (Metric\n" +
                            "(name “usbDebugging”)\n" +
                            "(value “" + usbDebugging + "”)\n" +
                            "(weight 5)))");
                    engine.eval("(assert (Metric\n" +
                            "(name “BTdiscoverable”)\n" +
                            "(value “" + BTdiscoverable + "”)\n" +
                            "(weight 2)))");
                    engine.eval("(assert (Metric\n" +
                            "(name “scrnLock”)\n" +
                            "(value “" + scrnLock +"”)\n" +
                            "(weight 9)))");
                    engine.eval("(assert (Metric\n" +
                            "(name “simLock”)\n" +
                            "(value “" + simLock +"”)\n" +
                            "(weight 1)))");
                    engine.eval("(assert (Metric\n" +
                            "(name “unkSrcs”)\n" +
                            "(value “"+unkSrcs+"”)\n" +
                            "(weight 4)))");
                    engine.eval("(assert (Metric\n" +
                            "(name “harmApps”)\n" +
                            "(value "+ numHarmfulApps +")\n" +
                            "(weight 4)))");

                    engine.eval("(assert (Metric\n" +
                            "(name “playProtect”)\n" +
                            "(value “"+ playProtect +"”)\n" +
                            "(weight 5)))");
                    engine.eval("(assert (Metric\n" +
                            "(name “devTampTest”)\n" +
                            "(value “"+ devTampTest +"”)\n" +
                            "(weight 10)))");

                    engine.run();
                    //System.out.println(writer.toString());
                    String result = writer.toString();
                    System.out.println(result);
                    JOptionPane.showMessageDialog(null, result);
                }
                catch(Exception ee){
                    ee.getMessage();
                }

            }
        });
    }

    public static void main(String[] args) {
        JFrame jframe = new JFrame();
        jframe.setContentPane(new com.company.ExpertSystem().jpanel);
        jframe.setDefaultCloseOperation(jframe.EXIT_ON_CLOSE);
        jframe.pack();
        jframe.setVisible(true);

    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
*/